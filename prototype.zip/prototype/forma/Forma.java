package git.prototype.forma;

public interface Forma extends Cloneable {
  void imprimir();
  Forma clonar();
}